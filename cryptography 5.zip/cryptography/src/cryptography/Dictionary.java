

package cryptography;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class Dictionary {
			private static String [] dictionary;
			
			public Dictionary(){
				try {
					dictionary = readFile();
				} catch (FileNotFoundException e) {
					System.out.println("Error dictionary not found n/Advise to be better");
					e.printStackTrace();
				}
			}
	/*	reads a file into an arraylist 
	 * populates dictionary array
	 */
	public static String[] readFile() throws FileNotFoundException {
		Scanner scan = new Scanner(new File("wordlist.txt"));
		ArrayList<String> StringArrayList = new ArrayList<String>();
		while (scan.hasNextLine()) {
			StringArrayList.add(scan.nextLine());
		}
		String[] StringArr = new String[StringArrayList.size()];
		for (int i = 0; i < StringArrayList.size(); i++) {
			StringArr[i] = StringArrayList.get(i);
		}
		scan.close();
		return StringArr;
	}
	 public String get(int index){
		 return dictionary[index];
	 }
	
	 public boolean contains(String str){
		 if (getPosition(str)==0){
			 return false;
		 }
		 else return true;
	 }
	 
	public int getPosition(String word){
			int min = 0;
			int mid;
			int max=dictionary.length-1;
			while (min<=max) {
				mid=(min+max)/2;
				if (dictionary[mid].compareTo(word)<0) {
					min = mid + 1;
				} else if (dictionary[mid].compareTo(word)>0){
					max=mid-1;
				} else{
					return mid;
				}
			}
			return (0);
		}

	public int length(){
		return dictionary.length;

	}
}

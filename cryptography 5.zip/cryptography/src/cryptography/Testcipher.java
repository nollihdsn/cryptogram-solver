package cryptography;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Testcipher {
    
	public static void main(String[]args) throws IOException{
		String [] wordlist = Dictionary.get();
		System.out.println(wordlist.length);

		System.out.println(wordlist[3]);
		
		Message n =new Message(2);
		System.out.println(n.toString());

	}

	
}

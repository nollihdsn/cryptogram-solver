package cryptography;

import java.io.FileNotFoundException;

	/* extends standard crypto solver
	 * has the ability to deal with words not in the dictionary ie misspelled words and author names 
	 * 
	 */

public class MisspelledCryptogramSolver extends StandardCryptogramSolver {

}
